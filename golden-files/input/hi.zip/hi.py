

def hi():
    print "hi"
